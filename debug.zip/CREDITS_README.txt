CREDITS

GRAPHICS, MUSIC, WRITING, DESIGN and EVERYTHING
Miro Haverinen /Happy Paintings/ orange

except for...

ANIMATION 
(including harvestman walk cycle, necromancy, expolosive 
vial and priest's lantern)
Jay/Janne

MUSIC
The intro track Ghostpocalypse - 5 Apotheosis
	Kevin MacLeod
Dozens of sound samples by 
	Taira Komori
Sound samples from the Cinematic Drums set by 
	Loop Loft
And hundreds of small sound samples from 
	freesound.org

PLUGINS USED
Yanfly Engine Plugins + Chickie Collaboration
	YEP_FootstepSounds
Yanfly Engine Plugins
 	YEP_BattleEngineCore
 	YEP_BaseParamControl
 	YEP_SaveEventLocations
 	YEP_BuffsStatesCore
 	YEP_X_CriticalControl
 	YEP_DamageCore
 	YEP_GabWindow
 	YEP_EventChasePlayer
 	YEP_StopMapMovement
 	YEP_OptionsCore
 	YEP_KeyboardConfig
 	YEP_MainMenuManager
 	YEP_StatusMenuCore
 	YEP_ItemSynthesis
 	YEP_DashToggle
	YEP_MessageCore
Fallen Angel Olivia
 	Olivia_OctoBattle
	Olivia_MetaControls
Visustella
 	Archeia_Steamworks
Tor Damian Design / Galenmereth
 	TDDP_FluidTimestep
 	TDDP_ManageDashing
DreamX
	DreamX_ChoiceHelp
Terrax
 	TerraxLighting
Izyees Fariz
 	Izy_RemoveOption
Galv - galvs-scripts.com
 	Galv_ExAgiTurn
 	GALV_BustMenu
DK (Denis Kuznetsov)
 	DK_Name_Input
Atreyo Ray
 	ARP_CommandIcons
Victor Sant
 	VE_BasicModule
 	VE_FogAndOverlay
Hime - HimeWorks (http://himeworks.com)
 	HIME_EndPhaseTriggers
 	HIME_FollowerEventTouch
 	HIME_CounterAfterHit
 	HIME_StateChangeAnimations
 	HIME_StateDamageModifiers
 	HIME_GuestFollowers
 	HIME_PreTitleEvents
 	HIME_DisabledChoiceConditions
 	HIME_LargeChoices
 	HIME_ConditionalChoiceText
Coelocanth
 	physical_attack_animation

GAME TESTING AND GAME FEEDBACK WITH 
THE ORIGINAL BUILD OF THE GAME
thedeanreynolds
N0ught
Mom/Fern
Mask
Koukee
Kill_Switch-X
Ken
Heartless Angel
Stern
Sammy
Magot
Edgozz
Kumada

BRAINSTORMING AND DESIGN HELP
Mask
Heartless Angel
Kill_Switch-X
Kumada
Lauri
And many others...

DISCORD
Starting the discord channel
Jacob Hunt
Moderator/dungeon masters/general help
Kill_Switch-X/Isayah, chilly, The Sandman, Chato

The game was made with RPG MAKER MV that
is developed by KADOKAWA and Yoji Ojima. 
RPG Maker is published by Degica.


Thanks to everyone who has been supporting the 
development of the game for the past two years. There 
are too many names that deserve a mention here that I 
would surely forget some important ones, so let's just 
not mention anyone. A perfect solution. No, but really, 
thank you everyone! The game wouldn't exist without you!


SPECIAL THANKS
The chibi version of the Crow Mauler was based on fanart
made by Vervain @VervainVanity

The character Jeanna was based on orginal character by 
Mom/Fern

The character Seril was based on original character by
Mask

The character Isayah was based on original character by
Kill_Switch-X


Special thanks to Youtube channels of Neco the Sergal
and RiskRim